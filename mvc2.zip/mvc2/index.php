
	  <?php
         
          // Charge modele qui gere la bdd
          require('controller/controller.php');
            
          try {
              
              if(isset($_GET['action'])){
                  loadController($_GET['action']);
              }else{
                  accueil($_GET['search']);
              }
              
              
          }
          
          catch (Exception $e){
              
              $erreur= $e->getMessage();
              require ('vue/vueErreur.php');

          }
	  ?>
	 