<?php
    if (isset($_GET['action'])){
                  //Je regarde si je suis sur video
                  if($_GET['action'] == "video"){
                       if(isset($_GET['id'])) { 
                           $id = intval($_GET['id']);
                           if($id != 0) {

                               video($id);


                           }else{

                              throw new Exception("l'ID n'est pas un int"); 
                           }

                       }else {
                           throw new Exception("Il n'y a pas d'identifiant sur la vidéo demandée");
                       }
                  }
    }
?>