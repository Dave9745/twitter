<?php
     // Charge modele qui gere la bdd
     require('modele/modele.php');

    function accueil($search = null){
        if ($search == null){
            $videos = getVideos();
            
            
        }else{
            $videos = getRecherche($search);
            
        }
        require('vue/vueAccueil.php');
    }

    function video($id_video){
        $video = getVideo($id_video);
        require("vue/vueVideo.php");
    }

    function erreur($erreur){
        require("vue/vueErreur.php");
    }

    
    function utilisateur($id_utilisateur){
        //Je récupère les infos de l'utilisateur
        $utilisateur = getUtilisateur($id_utilisateur);
        
        //Je récupère la liste des vidéos de cet utilisateurs
        $videos = getVideoByUtilisateur($id_utilisateur);
        
        require("vue/vueUtilisateur.php");
    }

    function loadController($action){
        
        require("controller/controller".$action.".php");
    }

   