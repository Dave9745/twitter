<?php
    

    function getVideos(){
    
                  $bdd = getBdd();
                  $req = $bdd->prepare('SELECT videos.id as video_id, Titre, nom, utilisateurs.id as user_id FROM videos INNER JOIN utilisateurs ON utilisateurs.id = videos.utilisateurs_id ');
                  $req->execute();
                  $result = $req->fetchAll();
        
                  return $result;
        
    }

    function getVideo($id_video) {
        
                  $bdd = getBdd();
                  $req = $bdd->prepare('SELECT * FROM videos 
                  INNER JOIN utilisateurs ON utilisateurs.id = videos.utilisateurs_id WHERE videos.id = :id');
                  $req->BindParam(':id', $id_video, PDO::PARAM_INT);
                  $req->execute();
        
                  if($req->rowCount() == 1){
                      $result = $req->fetch();
                      return $result;
                  }else{
                      throw new Exception ("La video ".$id_video." n'existe pas");
                  }
            }
    
     function getVideoByUtilisateur($id_utilisateur) {
        
                  $bdd = getBdd();
                  $req = $bdd->prepare('SELECT * FROM videos WHERE utilisateur_id = :id');
                  $req->BindParam(':id', $id_utilisateur, PDO::PARAM_INT);
                  $req->execute();
                  $result = $req->fetchAll();
                  return $result;
        
    }

    function getUtilisateur($id_utilisateurs){
        
        $bdd = getBdd();
        $req = $bdd->prepare('SELECT * FROM utilisateurs WHERE id = :id');
        $req->BindParam(':id', $id_utlisateurs, PDO::PARAM_INT);
        $req->execute();
        
        if($req->rowCount() == 1){
            $result = $req->fetch();
            return $result;
        }else{
            throw new Exception ("Cet utilisateur n'existe ");
        }
        
    }

    function getRecherche($recherche){
        
        $bdd = getBdd();
        $req = $bdd->prepare('SELECT * FROM videos INNER JOIN utilisateurs ON videos.utilisateurs_id = utilisateurs.id WHERE Titre LIKE \'%'.$recherche.'%\'');
        $req->execute();
        $result = $req->fetchAll();
        
        return $result;
        
    }


    function getBdd() {
        
        $bdd = new PDO('mysql:host=localhost;dbname=partagetavid;charset=utf8', 'root','', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        
        return $bdd;
    }

    
?>
