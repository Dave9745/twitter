<?php
$titre = "Vous regardez : ".$video['Titre']." post";
?>

<?php
ob_start();
?>

<h1>Vous regardez <?php echo $video['Titre'] ?></h1>
<?php echo $video['nom']; ?>
<p>Cliquez pour afficher le player</p>

<?php
$contenu = ob_get_clean();
?>
<?php
require("gab.php");
?>