<?php

$titre = "Erreur est survenue";

ob_start();
 ?>
    <p class="alert alert-danger">
    <?php    
    echo "Une erreur est survenue".$erreur;
    ?>
    </p>
<?php
    $contenu = ob_get_clean();

    require("gab.php");
?>