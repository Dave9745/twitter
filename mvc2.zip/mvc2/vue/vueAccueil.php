<?php 
    $titre = "Accueil";

    ob_start();
?>
<div class="row">
	  <?php
	  
	  foreach($videos as $video) {
          
	  ?>
	  <div class="col-md-4">
          <h2><?php echo $video['Titre']; ?></h2>
          <p>Description ...</p>
          <p><a class="btn btn-default" href="index.php?action=video&id=<?php echo $video['video_id']; ?>" role="button">Voir &raquo;</a>-<?php echo $video['nom']; ?></p>
        </div>
	  
	  <?php }?>
        
        <form method="get" action="">
            <input type="text" name="search">
            <input type="submit">
        </form>
</div>
<?php

$contenu = ob_get_clean();

require ('gab.php');

?>