<?php 
    $titre = "Détails utilisateur";

    ob_start();
?>
<div class="row">
	  <?php
	  
	  foreach($videos as $video) {
	  ?>
	  <div class="col-md-4">
          <h2><?php echo $video['Titre']; ?></h2>
          <p>Description ...</p>
          <p><a class="btn btn-default" href="index.php?action=video&id=<?php echo $video['id']; ?>" role="button">Voir &raquo;</a></p>
        </div>
	  
	  <?php }?>
        
        
</div>
<?php

$contenu = ob_get_clean();

require ('gab.php');

?>