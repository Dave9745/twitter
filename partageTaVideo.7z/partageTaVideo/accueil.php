<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link rel="stylesheet" href="fonts/fa/css/font-awesome.min.css">
    <link rel="stylesheet" href="partage.css">
    <?php
    
        session_start ();

        require('bddconn.php');

        if(isset($_SESSION['login']) AND isset($_SESSION['pwd'])){

            require('navbar.php');      
            

           }else{

            header('Location:login.php');

        }
     
   
?>
    
</head>

<body>
    
   
    <div class="col-lg-6 col-lg-offset-4 accroche"><i class="fa fa-hand-peace-o fontawesome"></i>Crème de la crème de tes vids !</div> 
    
    <div class="container menuvid">
        <div class="col-lg-12">
        
        
        <p class="last">Dernières vidéos</p>
        <p class="last">------------------------------------------------------<p><a class="a btn btn-warning" href="addvid.php" id="add">+ Ajouter une vidéo</a></p><br/>

        <?php 

             $sql = "SELECT * FROM videos";
             $result = mysql_query($sql);

             while ($row = mysql_fetch_assoc($result)){

                 $link = substr($row['link'],32,11);

                  echo "<div class='col-lg-6 vid'><a href='https://www.youtube.com/watch?v=".$link."'><img width='160' height='115' src='http://i1.ytimg.com/vi/".$link."/default.jpg'>&nbsp;&nbsp;<span class='a'>".$row['Titre']."</span></a></p></span></div>"; 

             }

        ?>
    </div>
        
    </div>
    
    
   
</body>
</html>
