<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <?php require('navbar.php'); ?>
</head>

<body>
    
    <div class="container">
        <form class="col-lg-3 col-lg-offset-4" action="traitlogin.php" method="post" >
          <legend>T'as pas de vie? Alors connecte toi :)</legend>
            <div class="form-group">
              <label for="mail">Ton E-mail : </label>
              <input name="mail" type="text" class="form-control" required>
            </div>
            
            <div class="form-group">
              <label for="password">Ton Mot d pass : </label>
              <input name="password" type="password" class="form-control" required>
            </div>
            <?php if(isset($_GET['er'])){
                    echo "<p style='color:red'>Nope !!<p><br/>";
                  }
            ?>
            <p>Pas de compte? <a href="inscription.php">Inscrit-toi</a></p>
            
            <button type="submit" class="btn btn-info">Ready? Set? Gooo!</button>
        </form>
    </div>        

</body>
</html>
