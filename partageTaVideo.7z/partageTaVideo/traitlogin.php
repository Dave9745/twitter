<?php
     require('bddconn.php');
    
     $sql = "SELECT * FROM utilisateurs WHERE email ='".$_POST['mail']."' AND motdepasse='". $_POST['password']."';";
     $result = mysql_query($sql);
     $num_rows = mysql_num_rows($result);

     if($num_rows > 0){
        
        $row = mysql_fetch_assoc($result); 
        $mail = $_POST['mail'];
        $password = $_POST['password'];

        if($mail == $row['email'] && $password == $row['motdepasse']){
            
            session_start ();
		
            $_SESSION['login'] = $_POST['mail'];
            $_SESSION['pwd'] = $_POST['password'];
            
            header('Location:accueil.php');

        }else{

            header('Location:login.php?er=true');
            
        }
    }else{
         
         header('Location:login.php?er=true');
         
     } 
    
    ?>
