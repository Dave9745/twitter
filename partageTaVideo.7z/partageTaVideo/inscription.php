<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <?php require('navbar.php'); ?>
</head>

<body>
    
    <div class="container">
        <form class="col-lg-3 col-lg-offset-4" action="traitinscription.php" method="post" >
          <legend>Dis nous tout!</legend>
            <div class="form-group">
              <label for="nom">Ton nom* : </label>
              <input name="nom" type="text" class="form-control" placeholder="NOLIFE" required>
            </div>
            <div class="form-group">
              <label for="prenom">Ton prénom* : </label>
              <input name="prenom" type="text" class="form-control" placeholder="Jean-Michel" required>
            </div>
            <div class="form-group">
              <label for="age">Vieux comment?* : </label>
              <input name="age" type="text" class="form-control" placeholder="200 ans" required>
            </div>
            <div class="form-group">
              <label for="mail">Ton e-mail* : </label>
              <input name="email" type="text" class="form-control" placeholder="jeanmichelnolife@hotmail.com" required>
            </div>
            <?php if(isset($_GET['er'])){
                    echo "<p style='color:red'>Wesh! Tu ne sais pas qu'est ce qu'une adresse e-mail?<p><br/>";
                  }
            ?>
            <div class="form-group">
              <label for="password">Mot de passe* : </label>
              <input name="password" type="password" class="form-control" required>
            </div>
             <div class="form-group">
              <label for="password">Confirmation* : </label>
              <input name="passwordconf" type="password" class="form-control" required>
            </div>
            <?php if(isset($_GET['erp'])){
                    echo "<p style='color:red'>Et voilà ça ne sais pas taper un deux mot de passe identiques!<p><br/>";
                  }
            ?>
            <div class="form-group">
              <label for="pseud">Ton Pseudo* : </label>
              <input name="pseud" type="text" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-info">Écartez-vous j'arrive!</button>
        </form>
    </div>        

</body>
</html>
