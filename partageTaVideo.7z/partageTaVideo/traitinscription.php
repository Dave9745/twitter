<?php

    require('bddconn.php');

    if(!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['age']) AND !empty($_POST['email']) AND !empty($_POST['pseud'])){
        
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $age = $_POST['age'];
        $mail = $_POST['email'];
        $password = $_POST['password'];
        $passwordconf = $_POST['passwordconf'];
        $pseud = $_POST['pseud'];
        
        if (preg_match("#^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]{2,}\.[a-z]{2,4}$#", $_POST['email'])){
            
            if($password == $passwordconf){
            
                echo "Tout est correct";

                $sql = "INSERT INTO utilisateurs VALUES ('NULL', '".$nom."', '".$prenom."', '".$age."', '".$mail."', '".$password."', '".$pseud."');";
                
                $result = mysql_query($sql);
                
                session_start ();
		
                $_SESSION['login'] = $mail;
                $_SESSION['pwd'] = $password;
            
                header('Location:accueil.php');
                
            }else{
            
                header('Location:inscription.php?erp=true');
                
            }
            
        }else{
            
            header('Location:inscription.php?er=true');
            
        }
        
    }else{
        
        echo "Il manque des choses !!";
    }
?>