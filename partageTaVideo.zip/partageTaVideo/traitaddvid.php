<?php
    require('bddconn.php');

    $linkvid = $_POST['vid'];
    $titre = substr($_POST['titre'],0,35)."...";
    $categ = $_POST['categorie'];
    $description = $_POST['description'];
    
    $sql = "INSERT INTO videos VALUES ('NULL', '".$linkvid."', '".$titre."', '".$categ."', '".$description."');";
    $result = mysql_query($sql);

    header('Location:accueil.php');
?>