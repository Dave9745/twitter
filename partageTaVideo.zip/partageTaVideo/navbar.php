<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <link rel="stylesheet" href="fonts/fa/css/font-awesome.min.css">
    <link rel="stylesheet" href="partage.css">
</head>

<body>
    
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header" class="col-lg-4">
          <a class="navbar-brand" href="accueil.php"><i class="fa fa-hand-peace-o"></i>&nbsp;&nbsp;PartageTaVid</a>
        </div>
        <form>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="accueil.php">Accueil</a></li>
              <?php 
                    
                    if(isset($_SESSION['login']) AND isset($_SESSION['pwd'])){
                        
                        require('bddconn.php');
                        $sql = "SELECT * FROM utilisateurs WHERE email ='".$_SESSION['login']."';";
                        $result = mysql_query($sql);
                        $num_rows = mysql_num_rows($result);
                        
                        if($num_rows > 0){
                            
                            $row = mysql_fetch_assoc($result); 
                            echo "<li><a href='#'>".$row['prenom']."</a></li>";
                            
                        }else{
                            
                            echo "<li><a href='login.php'>Unknow</a></li>";
                            
                        }
                    }else{
                        
                        echo "<li><a href='login.php'>Se connecter</a></li>";
                        
                    }
                ?>

              <li><input type="search" class="form-control" placeholder="You cherche what?" name="the_search"></li>
              <li><button type="button" class="btn btn-success"><i class="fa fa-search"></i></button></li> 
             <li><a href="deco.php">Déconnexion</a></li>  
            </ul>
        </form>  
        
      </div>
    </nav><br/><br/><br/><br/><br/><br/> 

</body>
</html>
