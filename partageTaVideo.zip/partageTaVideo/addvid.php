<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
    <?php
        session_start();
        require('navbar.php'); 
    ?>
</head>

<body>
    
    
    <form class="col-lg-3 col-lg-offset-4" action="traitaddvid.php" method="post" >
        <legend>Ta video:</legend>
        <div class="form-group">
          <label for="vid">Baah... Ta vidéo(lien)* : </label>
          <input name="vid" type="text" class="form-control" placeholder="http://www.youtube.com/watch?v=blablabla" required />
        </div>
        <div class="form-group">
          <label for="titre">Qui s'appelle?* : </label>
          <input name="titre" type="text" class="form-control" placeholder="Le petit poisson ou le gros" required />
        </div>
        <div class="form-group">
          <label for="categorie">C'est quel type?* : </label>
          <input name="categorie" type="text" class="form-control" placeholder="débilité profonde" required />
        </div>
        <div class="form-group">
          <label for="description">De quoi ça parle du coup?* : </label>
          <textarea name="description" type="text" class="form-control" placeholder="Genre c'est un crétin qui fait du skate sur une chaise" required ></textarea>
        </div>
        <button type="submit" class="btn btn-info">Envoyer</button>
    </form>
    
</body>
</html>
